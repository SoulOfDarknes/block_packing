export function generateColorForSize(width: number, height: number): string {
    let hash = width * 31 + height * 17;
    return `hsl(${hash % 360}, 60%, 70%)`;
}