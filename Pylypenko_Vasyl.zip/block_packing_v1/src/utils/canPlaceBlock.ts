
export function canPlaceBlock(memo: { [x: string]: boolean; }, spaceOccupied: any[][], block: { initialOrder?: number; rotated?: boolean; width: number; height: number; }, x: number, y: number, containerWidth: number, containerHeight: number) {
    const key = `${x},${y},${block.width},${block.height}`;
    if (memo[key] !== undefined) {
        return memo[key];
    }

    if (x + block.width > containerWidth || y + block.height > containerHeight) {
        memo[key] = false;
        return false;
    }
    for (let h = y; h < y + block.height; h++) {
        for (let w = x; w < x + block.width; w++) {
            if (spaceOccupied[h][w]) {
                memo[key] = false;
                return false;
            }
        }
    }
    memo[key] = true;
    return true;
}