import { Block, PackedBlock, PackingResult } from '../interfaces/index';
import { canPlaceBlock } from './canPlaceBlock';
import { isValidInput } from './isValidInput';

export function packBlocks(blocks: Block[], containerWidth: number, containerHeight: number): PackingResult {
    if (!isValidInput(blocks, containerWidth, containerHeight)) {
        throw new Error('Invalid input data');
    }

    const spaceOccupied = Array.from({ length: containerHeight }, () => Array(containerWidth).fill(false));
    const memo = {};

    const blocksWithOrder = blocks.map((block, index) => ({
        ...block,
        initialOrder: index,
        rotated: false
    }));

    const sortedBlocks = blocksWithOrder.sort((a, b) => (b.width * b.height) - (a.width * a.height));
    let packedBlocks: PackedBlock[] = [];
    let occupiedSpace = 0;
    let couldNotPlaceBlocks = false;

    for (const block of sortedBlocks) {
        let placed = false;
        for (let y = 0; y < containerHeight && !placed; y++) {
            for (let x = 0; x < containerWidth && !placed; x++) {
                if (canPlaceBlock(memo, spaceOccupied, block, x, y, containerWidth, containerHeight)) {
                    packedBlocks.push({
                        ...block,
                        x: x,
                        y: y
                    });

                    for (let h = y; h < y + block.height; h++) {
                        for (let w = x; w < x + block.width; w++) {
                            spaceOccupied[h][w] = true;
                        }
                    }

                    occupiedSpace += block.width * block.height;
                    placed = true;
                }
            }
        }

        if (!placed) {
            couldNotPlaceBlocks = true;
            break;
        }
    }

    let internalCavitiesArea = 0;
    if (!couldNotPlaceBlocks) {
        for (let h = 0; h < containerHeight; h++) {
            for (let w = 0; w < containerWidth; w++) {
                if (!spaceOccupied[h][w]) {
                    internalCavitiesArea++;
                }
            }
        }
    }

    const totalArea = containerWidth * containerHeight;
    const fullness = couldNotPlaceBlocks ? 0 : 1 - (internalCavitiesArea / totalArea);

    return {
        fullness,
        blockCoordinates: packedBlocks,
        couldNotPlaceBlocks
    };
}


