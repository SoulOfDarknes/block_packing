import { Block } from "../interfaces/index";

export function isValidInput(blocks: Block[], containerWidth: number, containerHeight: number) {
    if (containerWidth <= 0 || containerHeight <= 0) return false;
    for (const block of blocks) {
        if (block.width <= 0 || block.height <= 0) return false;
    }
    return true;
}