import { Block } from "../interfaces/index";

export async function loadBlocksData(filePath: string): Promise<{ blocks: Block[] }> {
    try {
        const response = await fetch(filePath);
        const data = await response.json();
        return {
            blocks: data.blocks
        };
    } catch (error) {
        console.error('Error loading JSON data:', error);
        throw error;
    }
}