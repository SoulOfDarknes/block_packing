export interface Block {
    width: number;
    height: number;
    initialOrder?: number;
    rotated?: boolean;
}

export interface Container {
    width: number;
    height: number;
}

export interface PackedBlock extends Block {
    x: number;
    y: number;
    initialOrder: number;
}

export interface PackingResult {
    fullness: number;
    blockCoordinates: PackedBlock[];
    couldNotPlaceBlocks: boolean;
}