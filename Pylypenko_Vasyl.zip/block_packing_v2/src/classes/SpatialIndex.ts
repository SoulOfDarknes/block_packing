import { Block } from "../interfaces/index";

export class SpatialIndex {
    width: number;
    height: number;
    freeAreas: { x: number, y: number, width: number, height: number }[];

    constructor(width: number, height: number) {
        this.width = width;
        this.height = height;
        this.freeAreas = [{ x: 0, y: 0, width: width, height: height }];
    }

    findFreeAreaForBlock(block: Block) {
        let bestArea = null;
        let minSizeDifference = Number.MAX_VALUE;

        for (const area of this.freeAreas) {
            if (block.width <= area.width && block.height <= area.height) {
                const widthDiff = area.width - block.width;
                const heightDiff = area.height - block.height;
                const sizeDifference = widthDiff + heightDiff;

                if (sizeDifference < minSizeDifference) {
                    bestArea = area;
                    minSizeDifference = sizeDifference;
                }
            }
        }

        return bestArea;
    }



    splitFreeArea(area: { x: number; y: number; width: number; height: number; }, block: Block) {
        const newAreas = [];

        if (area.y + area.height > block.y + block.height) {
            newAreas.push({
                x: area.x,
                y: block.y + block.height,
                width: area.width,
                height: area.y + area.height - (block.y + block.height)
            });
        }

        if (area.x + area.width > block.x + block.width) {
            newAreas.push({
                x: block.x + block.width,
                y: area.y,
                width: area.x + area.width - (block.x + block.width),
                height: block.height
            });
        }

        if (block.x > area.x) {
            newAreas.push({
                x: area.x,
                y: area.y,
                width: block.x - area.x,
                height: area.height
            });
        }

        if (block.y > area.y) {
            newAreas.push({
                x: area.x,
                y: area.y,
                width: area.width,
                height: block.y - area.y
            });
        }

        return newAreas;
    }



    updateFreeAreas(block: Block, placedBlockArea: { x: any; y: any; width: any; height: any; }) {
        this.freeAreas = this.freeAreas.filter(area => {
            const isOutsideX = area.x >= placedBlockArea.x + placedBlockArea.width || area.x + area.width <= placedBlockArea.x;
            const isOutsideY = area.y >= placedBlockArea.y + placedBlockArea.height || area.y + area.height <= placedBlockArea.y;
            return isOutsideX || isOutsideY;
        });
        const newAreas = this.splitFreeArea(placedBlockArea, block);
        this.freeAreas.push(...newAreas);
        this.freeAreas = this.freeAreas.filter(area => area.width > 0 && area.height > 0);
    }

}