export function generateColorForSize(width: number, height: number): string {
    const hue = (width * height) % 360;
    return `hsl(${hue}, 60%, 70%)`;
}