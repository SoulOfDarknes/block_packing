import { PackedBlock } from "../interfaces/index";

export function calculateFullness(blocks: PackedBlock[], containerWidth: number, containerHeight: number): number {
    const totalArea = containerWidth * containerHeight;
    const occupiedArea = blocks.reduce((area, block) => area + block.width * block.height, 0);
    const internalCavitiesArea = totalArea - occupiedArea;
    return 1 - (internalCavitiesArea / totalArea);
}