import { Block, PackedBlock, PackingResult } from '../interfaces/index';
import { SpatialIndex } from '../classes/SpatialIndex';
import { isValidInput } from '../validation/validation';
import { calculateFullness } from './calculateFullness';

export function packBlocks(blocks: Block[], containerWidth: number, containerHeight: number): PackingResult {
    if (!isValidInput(blocks, containerWidth, containerHeight)) {
        throw new Error('Invalid input data');
    }

    const spatialIndex = new SpatialIndex(containerWidth, containerHeight);
    let packedBlocks: PackedBlock[] = [];

    blocks.forEach((block, index) => {
        block.initialOrder = block.initialOrder ?? index;
    });

    const sortedBlocks = [...blocks].sort((a, b) => {
        const areaDifference = (b.width * b.height) - (a.width * a.height);
        if (areaDifference === 0) {
            return (a.initialOrder ?? 0) - (b.initialOrder ?? 0);
        }
        return areaDifference;
    });

    for (const block of sortedBlocks) {
        let rotatedBlock: Block = { ...block, rotated: false };
        let area = spatialIndex.findFreeAreaForBlock(rotatedBlock);

        if (!area && block.width !== block.height) {
            [rotatedBlock.width, rotatedBlock.height] = [block.height, block.width];
            rotatedBlock.rotated = true;
            area = spatialIndex.findFreeAreaForBlock(rotatedBlock);
        }

        if (area) {
            const packedBlock: PackedBlock = {
                ...rotatedBlock,
                x: area.x,
                y: area.y,
                initialOrder: block.initialOrder ?? 0
            };
            packedBlocks.push(packedBlock);
            spatialIndex.updateFreeAreas({ ...packedBlock, width: rotatedBlock.width, height: rotatedBlock.height }, area);
        }
        else {
            console.log(`Block with dimensions ${block.width}x${block.height} could not be placed.`);
        }
    }

    const fullness = calculateFullness(packedBlocks, containerWidth, containerHeight);
    return {
        fullness,
        blockCoordinates: packedBlocks,
        couldNotPlaceBlocks: packedBlocks.length < blocks.length
    };
}




