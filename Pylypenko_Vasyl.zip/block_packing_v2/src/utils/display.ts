import { Block, PackingResult } from "interfaces";
import { generateColorForSize } from "./generateColorForSize";
import { packBlocks } from "./packing";


export function recalculateLayout(containerElement: HTMLElement, blocks: Block[]): void {
    const containerWidth = containerElement.clientWidth;
    const containerHeight = containerElement.clientHeight;

    const result = packBlocks(blocks, containerWidth, containerHeight);
    displayResult(containerElement, result);
}

export function displayResult(containerElement: HTMLElement, result: PackingResult): void {
    containerElement.innerHTML = '';

    result.blockCoordinates.forEach((block) => {
        const blockElement = document.createElement('div');
        blockElement.style.position = 'absolute';
        blockElement.style.width = `${block.width}px`;
        blockElement.style.height = `${block.height}px`;
        blockElement.style.left = `${block.x}px`;
        blockElement.style.top = `${block.y}px`;
        blockElement.style.backgroundColor = generateColorForSize(block.width, block.height);
        if (block.initialOrder !== undefined) {
            blockElement.innerText = block.initialOrder.toString();
        }
        containerElement.appendChild(blockElement);
    });

    const fullnessElement = document.createElement('div');
    fullnessElement.innerText = `Fullness: ${result.fullness.toFixed(2)}`;
    containerElement.appendChild(fullnessElement);
}