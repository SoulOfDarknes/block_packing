import { loadBlocksData } from 'utils/dataLoader';
import { recalculateLayout } from './utils/display';

window.addEventListener('DOMContentLoaded', () => {
    const containerElement = document.getElementById('container');
    if (containerElement instanceof HTMLElement) {
        loadBlocksData('./mock/blocksData.json').then(({ blocks }) => {
            recalculateLayout(containerElement, blocks);

            window.addEventListener('resize', () => recalculateLayout(containerElement, blocks));
        });
    } else {
        console.error('Container element not found');
    }
});